```@meta
# Adjoint systems
```

## BiLQR

```@docs
bilqr
bilqr!
```

## TriLQR

```@docs
trilqr
trilqr!
```
