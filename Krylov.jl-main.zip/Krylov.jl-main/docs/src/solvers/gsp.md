```@meta
# Generalized saddle-point and non-Hermitian partitioned systems
```

## GPMR

```@docs
gpmr
gpmr!
```
