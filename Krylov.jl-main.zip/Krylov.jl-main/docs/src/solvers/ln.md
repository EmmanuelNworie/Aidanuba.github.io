```@meta
# Least-norm problems
```

## CGNE

```@docs
cgne
cgne!
```

## CRMR

```@docs
crmr
crmr!
```

## LNLQ

```@docs
lnlq
lnlq!
```

## CRAIG

```@docs
craig
craig!
```

## CRAIGMR

```@docs
craigmr
craigmr!
```

## USYMLQ

```@docs
usymlq
usymlq!
```
